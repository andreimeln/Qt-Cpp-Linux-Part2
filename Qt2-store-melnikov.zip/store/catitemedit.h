#ifndef CATITEMEDIT_H
#define CATITEMEDIT_H

#include <QFrame>
#include <QtSql>

#include "ui_catitemframe.h"
#include "dialogtpl.h"

class QSqlQuery;

namespace STORE {
namespace Catalogue {
namespace Item {

/*******************************************************************/

Data::Data(QObject *parent, QSqlQuery &qry)
    : QObject(parent) {

}

/*******************************************************************/

class Data : public QObject {

    Q_OBJECT

public:
    Data(QObject *parent=0) : QObject(parent) {}
    Data(QObject *parent, QSqlQuery &qry);
    // QImage vs. QPixmap pictogram
    QVariant Id;
    QString Code;
    QString Title;
    QDateTime From;
    QDateTime To;
    bool isLocal;
    QString Comment;
    Data *pParentItem;
};

/*******************************************************************/

class Frame : public QFrame {

    Q_OBJECT

public:
    Frame(QWidget * parent = 0);
    virtual ~Frame();

private:
    Ui::CatItemFrame ui;
    Data *Block;

public:
    void setDataBlock(Data *D) {Block = D; load(); }


public slots:
    void load();
    bool save();
    void is_good(bool *pOk);

signals:
    void error_message(const QString &);

};

/*******************************************************************/

class Dialog : public CommonDialog {

    Q_OBJECT

private:
    Frame *pFrame;

public:
    Dialog(QWidget *parent = 0);
    virtual ~Dialog();

public:
    void setDataBlock(Data *D) {pFrame->setDataBlock(D);}
};

/*******************************************************************/

} // namespace Item
} // namespace Catalogue
} // namespace STORE

#endif // CATITEMEDIT_H
