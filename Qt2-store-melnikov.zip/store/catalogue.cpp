#include "catalogue.h"
#include "posaction.h"

#include <Qt>
#include <QtDebug>
#include <QAction>
#include <QMenu>
#include <QtSql>

namespace STORE {
namespace Catalogue {

/************************************************************/

/*
class PositionedAction : public QAction {
    Q_OBJECT
};
*/

/************************************************************/

Model::Model(QObject *parent)
    : QAbstractTableModel(parent) {

//    QSqlQuery qry(
    QSqlQuery qry;
    qry.setForwardOnly(true);
    qry.prepare(
                "select\n"
                "   iid,\n"
                "   code,\n"
                "   title,\n"
                "   valid_from,\n"
                "   valid_to,\n"
                "   islocal,\n"
                "   acomment,\n"
                "   rid_parent,\n"
                "   alevel\n"
                "from catalogue;\n"
                );
    if (qry.exec()) { // exec() no longer needed here,
    while (qry.next()) {
        Item::Data *D = new Item::Data(this);
        Cat.append(D);
    }
    } else {
       //qCritical() << "Cannot execute query";
        QSqlError Err = qry.lastError();
        qCritical() << Err.nativeErrorCode();
        qCritical() << Err.databaseText().toUtf8().data();
        qCritical() << Err.driverText().toUtf8().data();
        //qDebug() << qry.executedQuery();
    }

    /*
    // TODO This is test catalog. Replace with a proper one
    {
    Item::Data *D = new Item::Data(this); // it has no constructor, inherits one from QObject
    D->Code = "111";
    D->Title = "Physics";
    D->From = QDateTime::currentDateTime();
    D->To = QDateTime();
    D->isLocal = false;
    Cat.append(D);
    }

    {
    Item::Data *D = new Item::Data(this); // it has no constructor, inherits one from QObject
    D->Code = "222";
    D->Title = "Mathematics";
    D->From = QDateTime::currentDateTime();
    D->To = QDateTime();
    D->isLocal = false;
    Cat.append(D);
    }

    {
    Item::Data *D = new Item::Data(this); // it has no constructor, inherits one from QObject
    D->Code = "333";
    D->Title = "Biology";
    D->From = QDateTime::currentDateTime();
    D->To = QDateTime();
    D->isLocal = false;
    Cat.append(D);
    }

    {
    Item::Data *D = new Item::Data(this); // it has no constructor, inherits one from QObject
    D->Code = "444";
    D->Title = "Valeology";
    D->From = QDateTime::currentDateTime();
    D->To = QDateTime();
    D->isLocal = false;
    Cat.append(D);
    }

    {
    Item::Data *D = new Item::Data(this); // it has no constructor, inherits one from QObject
    D->Code = "555";
    D->Title = "Literature";
    D->From = QDateTime::currentDateTime();
    D->To = QDateTime();
    D->isLocal = false;
    D->Comment = "Check if correct";
    Cat.append(D);
    }
    */
}

Model::~Model() {
}

int Model::rowCount(const QModelIndex &parent) const {
    if(! parent.isValid()) {
        return Cat.size(); // TODO Replace with correct number
    } else {
        return 0;
    }
}

int Model::columnCount(const QModelIndex &parent) const {
    if(! parent.isValid()) {
        return 6; // TODO Replace with correct number
    } else {
        return 0;
    }
}

QVariant Model::dataDisplay(const QModelIndex &I) const {

    Item::Data *D = Cat[I.row()];
    switch(I.column()) {
    case 0: return D->Code;
    case 1: return D->Title;
    case 2: return D->From;
    case 3: return D->To;
    case 4: return D->isLocal;
    case 5: return QVariant();
    }

}

QVariant Model::dataTextAlignment(const QModelIndex &I) const {

    int Result = Qt::AlignVCenter;
    Result |= I.column() == 1 ? Qt::AlignLeft : Qt::AlignHCenter;
    return Result; //QVariant();
}

Item::Data *Model::dataDataBlock(const QModelIndex &I) const {

    int R = I.row();
    if (R < 0 || R >= Cat.size() )
        return 0;
    return Cat[R];
}

QVariant Model::data(const QModelIndex &I, int role) const {

    //if ( role != Qt::DisplayRole)
    //    return QVariant();

    //return QString("%1,%2").arg(I.row()).arg(I.column());
    /*
    Item::Data *D = Cat[I.row()];
    switch(I.column()) {
    case 0: return D->Code;
    case 1: return D->Title;
    case 2: return D->From;
    case 3: return D->To;
    case 4: return D->isLocal;
    case 5: return D->Comment;
    }
    */
    //return QVariant();

    switch (role) {
    case Qt::DisplayRole : return dataDisplay(I);
    case Qt::TextAlignmentRole : return dataTextAlignment(I);
    default: return QVariant();
    }
}

QVariant Model::headerData(int section, Qt::Orientation orientation, int role) const {

    if(orientation != Qt::Horizontal)
        return QAbstractTableModel::headerData(section,orientation,role);

    switch(role) {
    case Qt::DisplayRole :
        switch(section) {
        case 0: return tr("Code");
        case 1: return tr("Title");
        case 2: return tr("From");
        case 3: return tr("To");
        case 4: return tr("Local"); //? tr("LOCAL") : QString(); // blank QString
        case 5: return QVariant(); //D->Comment.isEmpty() ? QString() : tr("CMT");
    }
    case Qt::TextAlignmentRole :
        return QVariant(Qt::AlignBaseline | Qt::AlignHCenter);

    case Qt::ForegroundRole:
    { // TODO make font bold
        QFont F;
        F.setBold(true);
        return F;
    }

    default: return QVariant();

    }
}

void Model::editItem(const QModelIndex &I, QWidget *parent) {
    Item::Dialog Dia(parent);
    Item::Data *D = dataDataBlock(I);
    if (!D)
        return;
    Dia.setDataBlock(D);
    Dia.exec();
    endResetModel(); // and now we can edit data
}

/************************************************************/

TableView::TableView(QWidget *parent)
    : QTableView(parent) {

    setContextMenuPolicy(Qt::CustomContextMenu);
    connect(this, SIGNAL(customContextMenuRequested(QPoint)),
            this, SLOT(contextMenuRequested(QPoint)));

    Model *M = new Model(this);
    setModel(M);

    {
     PosAction *A = actEditItem = new PosAction(this);
     A->setText(tr("Edit"));
     connect(A,SIGNAL(editItem(QModelIndex,QWidget*)), M, SLOT(editItem(QModelIndex,QWidget*)));
     addAction(A);
    }

    {
     QHeaderView *H = verticalHeader();
     H->setSectionResizeMode(QHeaderView::ResizeToContents); // resize vertical lines
    } {
     QHeaderView *H = horizontalHeader();
     H->setSectionResizeMode(QHeaderView::ResizeToContents);
     H->setSectionResizeMode(1, QHeaderView::Stretch);
    }
}

TableView::~TableView() {

};

//void TableView::editItem() {

    /*
    Item::Dialog Dia(this);
    Dia.exec();
    */
//}

void TableView::contextMenuRequested(const QPoint &p) {

    QMenu M(this);
    QModelIndex I = indexAt(p);
    if (I.isValid()) {
        actEditItem->I = I;
        actEditItem->pWidget = this;
        M.addAction(actEditItem);
    }
    M.exec(mapToGlobal(p));
}

/************************************************************/

} // namespace Catalogue
} // namespace STORE
